# MPCP Desktop App — Quick Start

## Files in this release
| File | Purpose |
|------|---------|
| `app.py` | Flask backend (patched v2.1) |
| `main_qt.py` | PyQt5 desktop wrapper |
| `run_app.bat` | One-click launcher (Windows) |
| `index.html` | Frontend UI (from original repo) |
| `scm.db` | SQLite database (auto-created) |

## Run
Double-click `run_app.bat` — it will:
1. Check Python is installed
2. Install `flask`, `openpyxl`, `PyQt5`, `PyQtWebEngine`
3. Start the Flask server on `localhost:5050`
4. Open the app in a native desktop window

## Requirements
- Python 3.9+ with pip
- Windows 10/11
- Internet connection (first run only, for pip install)

## Patches applied to app.py
| Patch | Fix |
|-------|-----|
| P1 | `app.secret_key` added — sessions now persist |
| P2 | `@app.teardown_appcontext` — DB connections closed properly |
| P3 | `app.run()` moved to true bottom after all routes |
| P4 | `/health` endpoint — used by PyQt to detect server readiness |
| P5 | `PORT` configurable via `MPCP_PORT` env var |
| P6 | Debug mode disabled in desktop mode (`MPCP_DEBUG=0`) |

## Troubleshooting
- **Port in use**: Change `MPCP_PORT=5051` in `run_app.bat`
- **PyQtWebEngine fails**: Install [VC++ Redistributable](https://aka.ms/vs/17/release/vc_redist.x64.exe)
- **Blank screen**: Ensure `index.html` is in the same folder as `app.py`
