@echo off
setlocal EnableDelayedExpansion
title Sipradi SC-MPCP Launcher

:: ─── Banner ───────────────────────────────────────────────────────────────
echo.
echo  =====================================================
echo    Sipradi SC-MPCP Desktop App  v2.1
echo    Managing Point / Checking Point System
echo  =====================================================
echo.

:: ─── Check Python ─────────────────────────────────────────────────────────
where python >nul 2>&1
if errorlevel 1 (
    echo  [ERROR] Python not found in PATH.
    echo  Download from https://python.org and ensure "Add to PATH" is checked.
    pause & exit /b 1
)

for /f "tokens=*" %%v in ('python --version 2^>^&1') do set PYVER=%%v
echo  Found: %PYVER%
echo.

:: ─── Install / upgrade dependencies ───────────────────────────────────────
echo  [1/3] Installing Python packages...
echo.

python -m pip install --upgrade pip --quiet
python -m pip install flask openpyxl PyQt5 PyQtWebEngine --quiet

if errorlevel 1 (
    echo.
    echo  [ERROR] pip install failed. Check internet connection.
    pause & exit /b 1
)

echo  [OK] All packages installed.
echo.

:: ─── Verify PyQtWebEngine (needs Visual C++ runtime on some systems) ───────
python -c "from PyQt5.QtWebEngineWidgets import QWebEngineView" >nul 2>&1
if errorlevel 1 (
    echo  [WARN] PyQtWebEngine import failed. Trying PyQt5 browser fallback...
    echo  You may need to install Microsoft Visual C++ Redistributable.
    echo  https://aka.ms/vs/17/release/vc_redist.x64.exe
    echo.
)

:: ─── Set working directory to script location ─────────────────────────────
cd /d "%~dp0"

:: ─── Check app.py and main_qt.py exist ────────────────────────────────────
if not exist "app.py" (
    echo  [ERROR] app.py not found in %~dp0
    pause & exit /b 1
)
if not exist "main_qt.py" (
    echo  [ERROR] main_qt.py not found in %~dp0
    pause & exit /b 1
)
if not exist "index.html" (
    echo  [WARN] index.html not found - app may not display correctly.
)

:: ─── Launch ───────────────────────────────────────────────────────────────
echo  [2/3] Starting MPCP Desktop App...
echo  (A window will open shortly. Close this console to exit.)
echo.

set MPCP_PORT=5050
set MPCP_DEBUG=0

python main_qt.py

:: ─── Exit handling ─────────────────────────────────────────────────────────
if errorlevel 1 (
    echo.
    echo  [ERROR] App exited with an error. See above for details.
    pause
) else (
    echo.
    echo  App closed normally.
)

endlocal
