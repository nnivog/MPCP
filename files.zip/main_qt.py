"""
main_qt.py  —  Sipradi SC-MPCP Desktop Launcher
Wraps Flask app in a PyQt5 QWebEngineView window.

Requirements:
    pip install PyQt5 PyQtWebEngine flask openpyxl
"""

import sys, os, time, threading
import urllib.request
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QSplashScreen,
    QAction, QToolBar, QLabel, QStatusBar, QMessageBox, QSizePolicy
)
from PyQt5.QtWebEngineWidgets import QWebEngineView, QWebEngineSettings
from PyQt5.QtCore import QUrl, Qt, QTimer, QThread, pyqtSignal
from PyQt5.QtGui import QIcon, QPixmap, QFont, QColor, QPainter

# ── Config ─────────────────────────────────────────────────────────────────
APP_TITLE   = "Sipradi SC-MPCP System"
APP_VERSION = "v2.1"
PORT        = int(os.environ.get("MPCP_PORT", 5050))
BASE_URL    = f"http://localhost:{PORT}"
HEALTH_URL  = f"{BASE_URL}/health"
MAX_WAIT_S  = 20          # seconds to wait for Flask to start
POLL_MS     = 300         # poll interval in ms


# ── Flask server thread ────────────────────────────────────────────────────

class FlaskThread(QThread):
    ready   = pyqtSignal()
    failed  = pyqtSignal(str)

    def run(self):
        try:
            os.environ["MPCP_DEBUG"] = "0"
            # Import here so it runs in this thread
            import app as flask_app
            flask_app.init_db()
            # Start Flask in a daemon thread (so it dies with the process)
            t = threading.Thread(
                target=lambda: flask_app.app.run(
                    debug=False, port=PORT, host="0.0.0.0",
                    use_reloader=False, threaded=True
                ),
                daemon=True
            )
            t.start()
            # Poll until Flask is up
            deadline = time.time() + MAX_WAIT_S
            while time.time() < deadline:
                try:
                    urllib.request.urlopen(HEALTH_URL, timeout=1)
                    self.ready.emit()
                    return
                except Exception:
                    time.sleep(0.3)
            self.failed.emit(f"Flask did not start within {MAX_WAIT_S}s")
        except Exception as e:
            self.failed.emit(str(e))


# ── Splash screen ──────────────────────────────────────────────────────────

def make_splash():
    px = QPixmap(480, 240)
    px.fill(QColor("#0f172a"))
    painter = QPainter(px)
    painter.setPen(QColor("#60a5fa"))
    font = QFont("Segoe UI", 22, QFont.Bold)
    painter.setFont(font)
    painter.drawText(px.rect(), Qt.AlignCenter, f"Sipradi SC-MPCP\n{APP_VERSION}")
    painter.setPen(QColor("#94a3b8"))
    small = QFont("Segoe UI", 10)
    painter.setFont(small)
    painter.drawText(0, 210, 480, 30, Qt.AlignCenter, "Starting local server…")
    painter.end()
    splash = QSplashScreen(px, Qt.WindowStaysOnTopHint)
    splash.show()
    return splash


# ── Main Window ────────────────────────────────────────────────────────────

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(f"{APP_TITLE} {APP_VERSION}")
        self.resize(1400, 860)
        self._build_toolbar()
        self._build_browser()
        self._build_statusbar()

    # ── Browser ────────────────────────────────────────────────────────────

    def _build_browser(self):
        self.browser = QWebEngineView()
        s = self.browser.settings()
        s.setAttribute(QWebEngineSettings.JavascriptEnabled, True)
        s.setAttribute(QWebEngineSettings.LocalStorageEnabled, True)
        s.setAttribute(QWebEngineSettings.ScrollAnimatorEnabled, True)
        s.setAttribute(QWebEngineSettings.PluginsEnabled, True)
        self.browser.loadStarted.connect(self._on_load_started)
        self.browser.loadFinished.connect(self._on_load_finished)
        self.setCentralWidget(self.browser)

    def load_app(self):
        self.browser.load(QUrl(BASE_URL))

    def _on_load_started(self):
        self.status.showMessage("Loading…")

    def _on_load_finished(self, ok):
        if ok:
            self.status.showMessage(f"Ready  •  {BASE_URL}", 3000)
        else:
            self.status.showMessage("⚠  Page load failed", 5000)

    # ── Toolbar ────────────────────────────────────────────────────────────

    def _build_toolbar(self):
        tb = QToolBar("Navigation")
        tb.setMovable(False)
        tb.setStyleSheet("""
            QToolBar { background:#1e293b; border:none; padding:4px 8px; spacing:6px; }
            QToolBar QToolButton {
                color:#e2e8f0; background:transparent; border:none;
                padding:5px 10px; border-radius:4px; font-size:13px;
            }
            QToolBar QToolButton:hover { background:#334155; }
            QToolBar QToolButton:pressed { background:#0f172a; }
            QLabel { color:#60a5fa; font-weight:bold; font-size:14px; padding:0 10px; }
        """)
        title_lbl = QLabel(f"⚡ {APP_TITLE}")
        tb.addWidget(title_lbl)

        sep = QLabel("|"); sep.setStyleSheet("color:#475569;")
        tb.addWidget(sep)

        back_act = QAction("◀ Back", self)
        back_act.triggered.connect(self.browser.back)
        tb.addAction(back_act)

        fwd_act = QAction("▶ Forward", self)
        fwd_act.triggered.connect(self.browser.forward)
        tb.addAction(fwd_act)

        reload_act = QAction("↻ Reload", self)
        reload_act.setShortcut("Ctrl+R")
        reload_act.triggered.connect(self.browser.reload)
        tb.addAction(reload_act)

        home_act = QAction("⌂ Home", self)
        home_act.triggered.connect(self.load_app)
        tb.addAction(home_act)

        # Spacer
        spacer = QLabel(""); spacer.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        tb.addWidget(spacer)

        about_act = QAction("ℹ About", self)
        about_act.triggered.connect(self._show_about)
        tb.addAction(about_act)

        self.addToolBar(tb)

    # ── Status bar ─────────────────────────────────────────────────────────

    def _build_statusbar(self):
        self.status = QStatusBar()
        self.status.setStyleSheet("background:#0f172a; color:#64748b; font-size:12px;")
        self.setStatusBar(self.status)
        self.status.showMessage("Waiting for server…")

    # ── About ──────────────────────────────────────────────────────────────

    def _show_about(self):
        QMessageBox.information(self, "About",
            f"<b>{APP_TITLE} {APP_VERSION}</b><br><br>"
            "Managing Point & Checking Point performance tracker<br>"
            "for Sipradi Trading Pvt. Ltd. — Logistics Department.<br><br>"
            f"<small>Running at {BASE_URL}</small>"
        )

    # ── Close ──────────────────────────────────────────────────────────────

    def closeEvent(self, event):
        reply = QMessageBox.question(
            self, "Exit", "Close MPCP Desktop App?",
            QMessageBox.Yes | QMessageBox.No
        )
        if reply == QMessageBox.Yes:
            event.accept()
        else:
            event.ignore()


# ── Entry point ────────────────────────────────────────────────────────────

def main():
    # Add the MPCP folder to path so app.py is importable
    here = os.path.dirname(os.path.abspath(__file__))
    if here not in sys.path:
        sys.path.insert(0, here)

    app_qt = QApplication(sys.argv)
    app_qt.setApplicationName(APP_TITLE)
    app_qt.setStyle("Fusion")

    splash = make_splash()
    win    = MainWindow()

    flask_thread = FlaskThread()

    def on_ready():
        splash.finish(win)
        win.show()
        win.load_app()

    def on_failed(msg):
        splash.close()
        QMessageBox.critical(None, "Startup Error",
                             f"Could not start Flask server:\n\n{msg}\n\n"
                             "Check that port 5050 is free and Flask is installed.")
        sys.exit(1)

    flask_thread.ready.connect(on_ready)
    flask_thread.failed.connect(on_failed)
    flask_thread.start()

    sys.exit(app_qt.exec_())


if __name__ == '__main__':
    main()
